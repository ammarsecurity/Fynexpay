import{n as e}from"./vue-i18n-DoUNJv36.js";import{D as t,E as n,St as ee,T as te,_ as r,b as i,bt as a,ct as o,g as s,mt as c,o as l,qt as u,tr as d,v as ne,vn as f,y as p}from"./runtime-core.esm-bundler-B4b-2GOK.js";import{a as m,c as re,i as h}from"./index-C9FLGxMv.js";import{n as ie,r as ae}from"./useProviders-DquWHaR3.js";var oe={class:`docs`},se={class:`page-head`},ce={class:`sub`},le={class:`row`},ue={class:`card platform-banner`},de={class:`banner-copy`},fe={class:`eyebrow`},pe={class:`rules`},me={class:`banner-side`},he={key:0,class:`platform-list`},g={class:`mono`,dir:`ltr`},_={class:`badge ok`},v={key:1,class:`empty-platform`},y={class:`steps`},b={class:`num`},x={class:`step-body`},S={class:`card`},C={class:`flow`},w={class:`flow-n`},T={class:`card`},E={class:`section-head`},D={class:`muted`},O={class:`code mono`,dir:`ltr`},k={class:`table-wrap`},A={class:`mono`},j={class:`muted`},M={class:`card`},N={class:`section-head`},P={class:`muted`},F={class:`code mono`,dir:`ltr`},I={class:`dash-grid`},L={class:`card`},R={class:`section-head`},ge={class:`muted`},_e={class:`code mono`,dir:`ltr`},ve={class:`card`},ye={class:`section-head`},be={class:`muted`},xe=[`disabled`],Se={class:`bullets`},Ce={key:0,class:`copy-box`},we={class:`mono`,dir:`ltr`},z={class:`card`},Te={class:`muted`},Ee={class:`providers`},De=[`src`],Oe={class:`card tip`},ke={class:`bullets`},Ae={class:`row actions`},je={key:0,class:`toast`},B=`YOUR_PLATFORM_API_KEY`,V=`YOUR_MERCHANT_BEARER`,H=re({__name:`Docs`,setup(re){let{t:H}=e(),{catalog:Me,ensureCatalog:Ne,logoOf:U}=ae(),W=f(``),G=f([]),K=f(``),q=null,Pe=`${h}/swagger/index.html`,J=s(()=>(G.value||[]).filter(e=>e.status===`Approved`)),Y=s(()=>J.value[0]?.domain||`shop.example.com`),Fe=s(()=>[{title:H(`docs.step1Title`),text:H(`docs.step1Body`),link:`/merchant`,linkText:H(`nav.overview`)},{title:H(`docs.step2Title`),text:H(`docs.step2Body`),link:`/merchant/platforms`,linkText:H(`nav.platforms`)},{title:H(`docs.step3Title`),text:H(`docs.step3Body`),link:null},{title:H(`docs.step4Title`),text:H(`docs.step4Body`),link:`/merchant/payments`,linkText:H(`nav.payments`)}]),Ie=s(()=>[H(`docs.flow1`),H(`docs.flow2`),H(`docs.flow3`),H(`docs.flow4`)]),Le=s(()=>[{field:`amount`,required:H(`docs.yes`),desc:H(`docs.fieldAmount`)},{field:`serviceType`,required:H(`docs.yes`),desc:H(`docs.fieldService`)},{field:`orderId`,required:H(`docs.no`),desc:H(`docs.fieldOrder`)},{field:`callbackUrl`,required:H(`docs.optional`),desc:H(`docs.fieldCallback`)},{field:`successUrl`,required:H(`docs.optional`),desc:H(`docs.fieldSuccess`)},{field:`failureUrl`,required:H(`docs.optional`),desc:H(`docs.fieldFailure`)}]),Re=s(()=>{let e={fib:H(`docs.provFib`),zaincash:H(`docs.provZain`),qi:H(`docs.provQi`),superqi:H(`docs.provSuperQi`),alqaseh:H(`docs.provAlqaseh`)},t=Me.value||[];return t.length?t.filter(e=>e.enabled!==!1).map(t=>({key:t.key,logo:ie(t.logoUrl)||U(t.key),desc:e[String(t.key).toLowerCase()]||H(`methods.customerSees`)})):[`Fib`,`ZainCash`,`Qi`,`SuperQi`,`Alqaseh`].map(t=>({key:t,logo:U(t),desc:e[t.toLowerCase()]||H(`docs.provFib`)}))}),X=s(()=>{let e=Y.value.startsWith(`localhost`)||Y.value.startsWith(`127.0.0.1`)?`http://${Y.value}`:`https://${Y.value}`;return`curl -X POST ${h}/v1/payments \\
  -H "Authorization: Bearer ${V}" \\
  -H "X-Api-Key: ${B}" \\
  -H "Content-Type: application/json" \\
  -H "X-Idempotency-Key: order-1001" \\
  -H "Origin: ${e}" \\
  -d '{
    "amount": 5000,
    "serviceType": "Monthly subscription",
    "orderId": "ORD-1001",
    "callbackUrl": "${e}/hooks/fynexpay",
    "successUrl": "${e}/success",
    "failureUrl": "${e}/failed"
  }'`}),ze=`{
  "id": "5bac8b83-....",
  "orderId": "ORD-....",
  "amount": 5000,
  "currency": "IQD",
  "status": "Pending",
  "provider": "PendingSelection",
  "description": "Monthly subscription",
  "checkoutUrl": "${h}/checkout/....",
  "createdAtUtc": "2026-08-11T19:40:36Z",
  "paidAtUtc": null,
  "expiredAtUtc": "2026-08-11T20:40:36Z",
  "failureReason": null,
  "customerPhone": null,
  "customerPhoneVerified": false
}`,Z=s(()=>`curl ${h}/v1/payments/PAYMENT_ID \\
  -H "Authorization: Bearer ${V}" \\
  -H "X-Api-Key: ${B}" \\
  -H "Origin: https://${Y.value}"`),Q=s(()=>`curl ${h}/v1/wallet \\
  -H "Authorization: Bearer ${V}"

curl -X POST ${h}/v1/payouts \\
  -H "Authorization: Bearer ${V}" \\
  -H "Content-Type: application/json" \\
  -d '{ "amount": 100000 }'`),Be=`{
  "id": "5bac8b83-....",
  "orderId": "ORD-1001",
  "amount": 5000,
  "currency": "IQD",
  "status": "Paid",
  "provider": "Fib",
  "description": "Monthly subscription",
  "checkoutUrl": "${h}/checkout/....",
  "createdAtUtc": "2026-08-11T19:40:36Z",
  "paidAtUtc": "2026-08-11T19:41:10Z",
  "expiredAtUtc": "2026-08-11T20:40:36Z",
  "failureReason": null,
  "customerPhone": "+9647800000000",
  "customerPhoneVerified": true
}`;function Ve(e){K.value=e,clearTimeout(q),q=setTimeout(()=>{K.value=``},2e3)}async function $(e,t){if(e){try{await navigator.clipboard.writeText(e)}catch{let t=document.createElement(`textarea`);t.value=e,document.body.appendChild(t),t.select(),document.execCommand(`copy`),document.body.removeChild(t)}Ve(t)}}return o(async()=>{Ne();try{let[e,t]=await Promise.all([m.get(`/api/merchant/webhook-secret`),m.get(`/api/merchant/platforms`)]);W.value=e.data.secret||``,G.value=t.data||[]}catch{W.value=``,G.value=[]}}),(e,o)=>{let s=ee(`RouterLink`);return c(),i(`div`,oe,[r(`div`,se,[r(`div`,null,[r(`h1`,null,d(e.$t(`docs.title`)),1),r(`p`,ce,d(e.$t(`docs.subtitle`)),1)]),r(`div`,le,[t(s,{class:`btn secondary`,to:`/merchant/platforms`},{default:u(()=>[n(d(e.$t(`docs.ctaPlatforms`)),1)]),_:1}),t(s,{class:`btn`,to:`/merchant/test`},{default:u(()=>[n(d(e.$t(`docs.ctaTest`)),1)]),_:1})])]),r(`section`,ue,[r(`div`,de,[r(`span`,fe,d(e.$t(`docs.platformBadge`)),1),r(`h2`,null,d(e.$t(`docs.platformTitle`)),1),r(`p`,null,d(e.$t(`docs.platformBody`)),1),r(`ul`,pe,[r(`li`,null,d(e.$t(`docs.ruleKey`)),1),r(`li`,null,d(e.$t(`docs.ruleCors`)),1),r(`li`,null,d(e.$t(`docs.ruleServer`)),1)])]),r(`div`,me,[J.value.length?(c(),i(`div`,he,[(c(!0),i(l,null,a(J.value,t=>(c(),i(`div`,{key:t.id,class:`platform-pill`},[r(`strong`,null,d(t.name),1),r(`span`,g,d(t.domain),1),r(`span`,_,d(e.$t(`status.Approved`)),1)]))),128))])):(c(),i(`div`,v,[r(`p`,null,d(e.$t(`docs.noPlatform`)),1),t(s,{class:`btn`,to:`/merchant/platforms`},{default:u(()=>[n(d(e.$t(`docs.addPlatform`)),1)]),_:1})]))])]),r(`section`,y,[(c(!0),i(l,null,a(Fe.value,(e,t)=>(c(),i(`article`,{key:t,class:`step card`},[r(`div`,b,d(t+1),1),r(`div`,x,[r(`h3`,null,d(e.title),1),r(`p`,null,d(e.text),1),e.link?(c(),ne(s,{key:0,class:`btn secondary sm`,to:e.link},{default:u(()=>[n(d(e.linkText),1)]),_:2},1032,[`to`])):p(``,!0)])]))),128))]),r(`section`,S,[r(`h2`,null,d(e.$t(`docs.flowTitle`)),1),r(`div`,C,[(c(!0),i(l,null,a(Ie.value,(e,t)=>(c(),i(`div`,{class:`flow-item`,key:t},[r(`span`,w,d(t+1),1),r(`span`,null,d(e),1)]))),128))])]),r(`section`,T,[r(`div`,E,[r(`div`,null,[r(`h2`,null,d(e.$t(`docs.createTitle`)),1),r(`p`,D,d(e.$t(`docs.createHint`)),1)]),r(`button`,{class:`btn secondary`,type:`button`,onClick:o[0]||=t=>$(X.value,e.$t(`docs.copied`))},d(e.$t(`docs.copy`)),1)]),r(`pre`,O,d(X.value),1),r(`h3`,null,d(e.$t(`docs.fieldsTitle`)),1),r(`div`,k,[r(`table`,null,[r(`thead`,null,[r(`tr`,null,[r(`th`,null,d(e.$t(`docs.field`)),1),r(`th`,null,d(e.$t(`docs.required`)),1),r(`th`,null,d(e.$t(`docs.desc`)),1)])]),r(`tbody`,null,[(c(!0),i(l,null,a(Le.value,e=>(c(),i(`tr`,{key:e.field},[r(`td`,A,d(e.field),1),r(`td`,null,d(e.required),1),r(`td`,null,d(e.desc),1)]))),128))])])]),r(`h3`,null,d(e.$t(`docs.responseTitle`)),1),r(`pre`,{class:`code mono`,dir:`ltr`},d(ze)),r(`p`,j,d(e.$t(`docs.checkoutHint`)),1)]),r(`section`,M,[r(`div`,N,[r(`div`,null,[r(`h2`,null,d(e.$t(`docs.walletTitle`)),1),r(`p`,P,d(e.$t(`docs.walletHint`)),1)]),r(`button`,{class:`btn secondary`,type:`button`,onClick:o[1]||=t=>$(Q.value,e.$t(`docs.copied`))},d(e.$t(`docs.copy`)),1)]),r(`pre`,F,d(Q.value),1)]),r(`div`,I,[r(`section`,L,[r(`div`,R,[r(`div`,null,[r(`h2`,null,d(e.$t(`docs.statusTitle`)),1),r(`p`,ge,d(e.$t(`docs.statusHint`)),1)]),r(`button`,{class:`btn secondary`,type:`button`,onClick:o[2]||=t=>$(Z.value,e.$t(`docs.copied`))},d(e.$t(`docs.copy`)),1)]),r(`pre`,_e,d(Z.value),1),o[4]||=te(`<div class="chips" data-v-79935feb><span class="badge warn" data-v-79935feb>Pending</span><span class="badge ok" data-v-79935feb>Paid</span><span class="badge danger" data-v-79935feb>Failed</span><span class="badge" data-v-79935feb>Cancelled</span></div>`,1)]),r(`section`,ve,[r(`div`,ye,[r(`div`,null,[r(`h2`,null,d(e.$t(`docs.webhookTitle`)),1),r(`p`,be,d(e.$t(`docs.webhookHint`)),1)]),r(`button`,{class:`btn secondary`,type:`button`,disabled:!W.value,onClick:o[3]||=t=>$(W.value,e.$t(`docs.copied`))},d(e.$t(`docs.copySecret`)),9,xe)]),r(`ul`,Se,[o[5]||=r(`li`,null,[r(`code`,null,`X-Fynexpay-Signature`)],-1),o[6]||=r(`li`,null,`HMAC-SHA256`,-1),r(`li`,null,d(e.$t(`docs.webhookPaidOnly`)),1)]),W.value?(c(),i(`div`,Ce,[r(`code`,we,d(W.value),1)])):p(``,!0),r(`pre`,{class:`code mono`,dir:`ltr`},d(Be))])]),r(`section`,z,[r(`h2`,null,d(e.$t(`docs.providersTitle`)),1),r(`p`,Te,[n(d(e.$t(`docs.providersHint`))+` `,1),t(s,{to:`/merchant/payment-methods`},{default:u(()=>[n(d(e.$t(`nav.paymentMethods`)),1)]),_:1})]),r(`div`,Ee,[(c(!0),i(l,null,a(Re.value,e=>(c(),i(`div`,{class:`provider`,key:e.key},[r(`img`,{class:`prov-logo`,src:e.logo,alt:``},null,8,De),r(`span`,null,d(e.desc),1)]))),128))])]),r(`section`,Oe,[r(`h2`,null,d(e.$t(`docs.tipsTitle`)),1),r(`ul`,ke,[r(`li`,null,d(e.$t(`docs.tip1`)),1),r(`li`,null,d(e.$t(`docs.tip2`)),1),r(`li`,null,d(e.$t(`docs.tip3`)),1),r(`li`,null,d(e.$t(`docs.tip4`)),1),r(`li`,null,d(e.$t(`docs.tipSwagger`)),1)]),r(`div`,Ae,[r(`a`,{class:`btn`,href:Pe,target:`_blank`,rel:`noopener`},d(e.$t(`docs.openApi`)),1),t(s,{class:`btn secondary`,to:`/merchant/platforms`},{default:u(()=>[n(d(e.$t(`docs.ctaPlatforms`)),1)]),_:1}),t(s,{class:`btn secondary`,to:`/merchant/payments`},{default:u(()=>[n(d(e.$t(`nav.payments`)),1)]),_:1})])]),K.value?(c(),i(`div`,je,d(K.value),1)):p(``,!0)])}}},[[`__scopeId`,`data-v-79935feb`]]);export{H as default};